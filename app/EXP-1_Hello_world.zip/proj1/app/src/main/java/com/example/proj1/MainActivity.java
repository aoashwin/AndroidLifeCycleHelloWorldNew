package com.example.proj1;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnCreate Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
    protected void onStart(){
        super.onStart();
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnStart Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
    protected void onResume(){
        super.onResume();
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnResume Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
    protected void onPause(){
        super.onPause();
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnPause Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
    protected void onStop(){
        super.onStop();
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnStop Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
    protected void onRestart(){
        super.onRestart();
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnRestart Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
    protected void onDestroy(){
        super.onDestroy();
        Toast toast=Toast.makeText(getApplicationContext(),
                "OnDestroy Invoked",Toast.LENGTH_LONG);
                toast.show();
    }
}
